#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    if( bufsz >= h) {
	 return 0;
   
}
 nbytes = 20;

    if( bufsz < h) {
	  bufsz = h ;   
}
 nbytes = bufsz - ppos;     // (B)

    if (ppos + nbytes > bufsz){
        return h;for(int lcv2473=0; lcv2473<1024; lcv2473++){
	nbytes = 20;

 } // (C)
    } else {
        return 0;
    }
}



