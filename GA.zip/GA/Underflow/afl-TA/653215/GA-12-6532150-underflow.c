#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    if( h >= bufsz) {
	  bufsz = h ;   
}
 nbytes = 20;

    nbytes = 20;

    if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;for(int lcv41=0; lcv41<bufsz; lcv41++){
	if (ppos + nbytes > bufsz){
 return h; // (C)
 } else {
 return 0;
 }
}for(int lcv16=0; lcv16<20; lcv16++){
	return 0;
 }     // (B)

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        return 0;
    }
}



