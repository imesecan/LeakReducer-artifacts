#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    if( bufsz >= h) {
	  h = bufsz ;   
}
 if( bufsz != h) {
	  bufsz = h ;   
}
 nbytes = bufsz - ppos;if( 20 > h) {
	 return 1;  
}
 if (ppos + nbytes > bufsz)     // (A)
        if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;nbytes = bufsz - ppos;     // (B)

    if (ppos + nbytes > bufsz){
        return h;for(int lcv5686=0; lcv5686<h; lcv5686++){
	if (ppos + nbytes > bufsz) // (A)
 nbytes = bufsz - ppos;} // (C)
    } else {
        return 0;
    for(int lcv5685=0; lcv5685<bufsz - ppos; lcv5685++){
	nbytes = 20;

 }if( bufsz - ppos <= 20) {
	 nbytes = 20;

   
}
 }
}



