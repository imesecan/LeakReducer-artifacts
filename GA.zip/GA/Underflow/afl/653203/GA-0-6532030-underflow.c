#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    if( bufsz != h) {
	  bufsz = h ;   
}
 nbytes = 20;

    if( 1024 >= h) {
	 return 0;  
}
 if (ppos + nbytes > bufsz)     // (A)
        return h;     // (B)

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        return 0;
    }
return h;}



