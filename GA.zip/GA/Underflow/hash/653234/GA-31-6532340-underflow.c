#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    nbytes = 20;

    if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;for(int lcv300=0; lcv300<20; lcv300++){
	if (ppos + nbytes > bufsz) // (A)
 nbytes = bufsz - ppos;}if( bufsz <= h) {
	 return 0;  
}
      // (B)

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        return 0;
    }
}
}



