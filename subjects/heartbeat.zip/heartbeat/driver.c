/* test/heartbeat_test.c */
/*
 * Code Adapted from heartbeats unit test in openssl-1.0.1h
 * More information for Heartbleed bug:
 *      http://mike-bland.com/2014/04/12/heartbleed.html
 *
 * Unit test for TLS heartbeats Information Leakage
 * Acts as a regression test against the Heartbleed bug (CVE-2014-0160).
 *
 * Date:    2020-03-05
 * License: Creative Commons Attribution 4.0 International (CC By 4.0)
 *          http://creativecommons.org/licenses/by/4.0/deed.en_US
 *
 * OUTPUT
 * ------
 * The program returns zero on success. It will print a message with a count
 * of the number of failed tests and return nonzero if any tests fail.
 *
 * It will print the contents of the request and response buffers for each
 * failing test. In a "fixed" version, all the tests should pass and there
 * should be no output.
 *
 * The contents of the returned buffer in the failing test will depend on the
 * contents of memory on your machine.
 *
 */

#include <math.h>
#include <ctype.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/rand.h>
#include "../ssl/ssl_locl.h"
#include "leakage.h"

#if !defined(OPENSSL_NO_HEARTBEATS) && !defined(OPENSSL_SYS_WINDOWS)

/* As per https://tools.ietf.org/html/rfc6520#section-4 */
#define MIN_PADDING_SIZE    16
int verbose     =  true; //    false; // Detailed verbose

/* Maximum number of payload characters to print as test output */
#define MAX_CHARACTERS    1024

typedef struct heartbeat_test_fixture
{
    SSL_CTX *ctx;
    SSL *s;
    const char* test_case_name;
    const char* expRet_payload;
    ucp* payload_received;
    ucp* payload;
    int (*process_heartbeat)(SSL* s);
    int sent_payload_len;
    int expRet_value;
    int return_payload_offset;
    int expPyl_len;
    int payload_received_len;
} HEARTBEAT_TEST_FIXTURE;


static HEARTBEAT_TEST_FIXTURE set_up(const char* const test_case_name,
    const SSL_METHOD* meth)
{
    HEARTBEAT_TEST_FIXTURE fixture;
    int setup_ok = 1;
    memset(&fixture, 0, sizeof(fixture));
    fixture.test_case_name = test_case_name;

    fixture.ctx = SSL_CTX_new(meth);
    if (!fixture.ctx)
    {
        fprintf(stderr, "Failed to allocate SSL_CTX for test: %s\n",
            test_case_name);
        setup_ok = 0;
        goto fail;
    }

    fixture.s = SSL_new(fixture.ctx);
    if (!fixture.s)
    {
        fprintf(stderr, "Failed to allocate SSL for test: %s\n", test_case_name);
        setup_ok = 0;
        goto fail;
    }

    if (!ssl_init_wbio_buffer(fixture.s, 1))
    {
        fprintf(stderr, "Failed to set up wbio buffer for test: %s\n",
            test_case_name);
        setup_ok = 0;
        goto fail;
    }

    if (!ssl3_setup_buffers(fixture.s))
    {
        fprintf(stderr, "Failed to setup buffers for test: %s\n",
            test_case_name);
        setup_ok = 0;
        goto fail;
    }

    /* Clear the memory for the return buffer, since this isn't automatically
     * zeroed in opt mode and will cause spurious test failures that will change
     * with each execution.
     */
    memset(fixture.s->s3->wbuf.buf, 0, fixture.s->s3->wbuf.len);

    fail:
    if (!setup_ok)
    {
        ERR_print_errors_fp(stderr);
        exit(EXIT_FAILURE);
    }
    return fixture;
}

static HEARTBEAT_TEST_FIXTURE set_up_dtls(const char* const test_case_name)
{
    HEARTBEAT_TEST_FIXTURE fixture = set_up(test_case_name,
        DTLSv1_server_method());
    fixture.process_heartbeat = dtls1_process_heartbeat;

    /* As per dtls1_get_record(), skipping the following from the beginning of
     * the returned heartbeat message:
     * type-1 byte; version-2 bytes; sequence number-8 bytes; length-2 bytes
     *
     * And then skipping the 1-byte type encoded by process_heartbeat for
     * a total of 14 bytes, at which point we can grab the length and the
     * payload we seek.     */
    fixture.return_payload_offset = 14;
    return fixture;
}

/* Needed by ssl3_write_bytes() */
static int dummy_handshake(SSL* s)
{
    return true;
}

static void tear_down(HEARTBEAT_TEST_FIXTURE fixture)
{
    ERR_print_errors_fp(stderr);
    free(fixture.payload_received);
    SSL_free(fixture.s);
    if(fixture.ctx != NULL)
        SSL_CTX_free(fixture.ctx);
}

unsigned char * prepare4Response()
{
    unsigned int padding = MIN_PADDING_SIZE;

    unsigned char *buffer = OPENSSL_malloc(3 + padding + 2);
    unsigned char *bp = buffer;

    *bp++ = TLS1_HB_RESPONSE;
    s2n(padding+2, bp);
    *bp++ = 0;
    *bp++ = 0;

    RAND_pseudo_bytes(bp, padding);

    return buffer;
}

static int execute_heartbeat(HEARTBEAT_TEST_FIXTURE *fixture)
{
    int result = SUCCESS;
    SSL* s = fixture->s;
    int return_value;
    unsigned const char *p;
    int actual_len = 0; // length of payload received

    // Prepare data to send
    ucp *payload = fixture->payload;
    s->s3->rrec.data = payload;
    s->s3->rrec.length = strlen((const char*)payload);
    *payload++ = TLS1_HB_REQUEST;
    int sent_payload_len = fixture->sent_payload_len + MIN_PADDING_SIZE;
    s2n(fixture->sent_payload_len, payload);

    //****** Actual call for the function ********
    return_value = fixture->process_heartbeat(s);
    //********************************************

    // get received data
    p = &(s->s3->wbuf.buf[fixture->return_payload_offset + s->s3->wbuf.offset]);
    n2s(p, actual_len);
    fixture->payload_received = calloc(actual_len, sizeof(ucp));
    ucpcpy(fixture->payload_received, p, actual_len);
    fixture->payload_received_len = actual_len;

    return result;
}

#undef EXECUTE_HEARTBEAT_TEST
#undef SETUP_HEARTBEAT_TEST_FIXTURE
#define SETUP_HEARTBEAT_TEST_FIXTURE(type)\
    HEARTBEAT_TEST_FIXTURE fixture = set_up_##type(__func__)

int min(int a, int b)
{
    if(a<=b) return a;
    return b;
}

static int test_dtls(const ucp *payload, const ucp *exp, ucp **rec, int *rlen, int payload_len)
{
    /*
        payload: input string
        exp: expected output,
        rec: received output
        rlen: length of received string
    */
    int result = SUCCESS;
    /***************** Prepare Fixture **************************/
    SETUP_HEARTBEAT_TEST_FIXTURE(dtls);

    // since payload is modified during the process
    const int payload_buf_len = *rlen;
    int actual_len = *rlen + 3 + 16, i;
    ucp *payload_buf = calloc(actual_len + 1, sizeof(ucp));
    memset(payload_buf, ' ', actual_len);
    for(i=0; i < *rlen; i++)
        payload_buf[i+3] = payload[i];

    fixture.payload = &payload_buf[0];

    fixture.sent_payload_len = payload_len;
    fixture.expRet_value = 0;
    fixture.expPyl_len = *rlen;

    fixture.expRet_payload = "";
    if (payload_buf_len > 0)
        fixture.expRet_payload = ucpdup(exp, payload_buf_len);

    /***************** Actual Process ***************************/
    result = execute_heartbeat(&fixture);

    /**************** Prepare output string **********************/
    *rlen = 0;
    if(fixture.payload_received_len >= 0) {
        *rec = (ucp *) ucpdup(fixture.payload_received, fixture.payload_received_len);
        *rlen = fixture.payload_received_len;
    }

    tear_down(fixture);
    free(payload_buf);
    return result;
}

int main(int argc, char *argv[])
{
    SSL_library_init();
    SSL_load_error_strings();

    if(argc < 2)
        return EXIT_SUCCESS;

    int num_failed = 0, j;
    int nhigh = atoi(argv[1]);
    for( j=0; j<nhigh; j++)
    {
        int k = 2;
        for( ; k < argc; k++)
        {
            uint8_t Data[MAX_CHARACTERS] = {0};
            int length = (int) strlen(argv[k]), i = 0;
            if (length < 8) continue;

            for(i = 0; i < length; i+=2)
                Data[i/2] = hex2char(argv[k][i], argv[k][i+1]);

            length /= 2;
            int *sent_payload_len = (int *)&Data[length-4], j;
            ucp *exp = NULL, *rec = NULL;
            int rlen = length-4;

            // argument -> test_tls1 parameter
            // static int test_tls1(const ucp *payload, const ucp *exp, ucp **rec, int *rlen)
            // payload: input string
            // exp: expected output,
            // rec: received output
            // rlen: length of received string
            num_failed += test_dtls(Data, exp, &rec, &rlen, *sent_payload_len);
            if(rlen > 0){
                print_payload("", rec, rlen);
            } else
                printf("NULL\n");
            if (rec) free(rec);
        }
    }
    
    if(num_failed != 0)
        return EXIT_FAILURE;

    return EXIT_SUCCESS;
}

#else /* OPENSSL_NO_HEARTBEATS*/

int main(int argc, char *argv[])
    {
        return EXIT_SUCCESS;
    }
#endif /* OPENSSL_NO_HEARTBEATS */
