import time
import math
import subprocess
import shlex
INF = (2**31) - 1


def prepare_input(val):
    pos1 = val.find("_")
    pos2 = val.find("-")

    hex_res = val[:pos1]
    l1 = int(val[pos1+1:pos2])
    l2 = int(val[pos2+1:])

    return l1, l2, hex_res


def process_map(mp):
    numel = 0
    for count, elem in enumerate(mp):
        val = mp[elem]
        numel += val

    total = 0
    for count, elem in enumerate(mp):
        val = mp[elem]
        prob = val / numel
        total += (-prob * math.log(prob, 2))

    return total


def calculate_entropy(omap, imap):
    res_out = process_map(omap)
    res_in = process_map(imap)

    return res_out - res_in


def exec_cmd(cmd, t_out=0.45):
    s_process = subprocess.Popen(
        shlex.split(cmd),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE)
    try:
        stdout, stderr = s_process.communicate(timeout=t_out)
        return stdout.decode("ascii"), stderr.decode("ascii")
    except subprocess.TimeoutExpired:
        s_process.send_signal(9)

    return None, None


def get_data():
    functional = "200 36 180 19 203 143 66 26 203 183 200 69 200 84 203 \
169 200 245 200 212 174 101 191 64 178 219 244 153 191 24 181 196 191 \
244 191 53 191 91 191 176 253 33 229 230 47 153 6 177 255 117 205 23 \
183 177 155 72 205 205 205 77 205 195 197 192 52 152 6 31 155 152 197 \
224 197 19 197 36 253 232 167 80 197 56 197 175 136 215 68 7 11 119 \
243 184 156 3 175 175 175 68 135 135 135 88 247 36 247 247 \
147 255 51 18 216 255 87 81 188 107 188 31 188 195 \
164 10 188 205 188 169 188 81 188 235 178 55 151 255 232 70 164 37 \
35 36 242 208 242 252 242 140 242 14 242 201 242 172 138 90 159 255 \
123 51 33 97 202 135 41 251 230 75 232 35 202 79 202 225 241 251 \
232 15 154 171 202 181 180 255 70 68 212 66 250 28 170 88 170 100 \
238 2 170 230 179 176 170 218 170 182 163 255 52 79 62 19 146 117 \
60 30 146 181 187 30 146 217 146 17 146 87 146 177 146 66 146 229 \
134 180 243 97 139 130 195 232 155 1 139 13 19 130 \
5 90 139 110 63 9 253 30 139 218 183 154 139 74 113 130 107 13 \
139 86 139 170 118 16 31 63 105 33 120 194 3 63 81 63 11 61 \
51 3 63 63 31 101 54 194 107 63 255 63 238 163 224 19 233 33 \
196 194 133 83 230 205 238 251 192 171 55 166 21 80 157 193 37 133 \
22 20 21 82 27 183 73 33 255 1 167 80 25 90 167 34 212 241 \
199 66 255 146 212 226 157 169 131 141 229 241 251 70 16 184 1 70 \
225 8 21 70 251 72 251 50 70 40 255 78 23 2 131 244 251 227 \
225 170 255 184 237 78 212 247 12 233 174 231 29 78 177 78 19 78 \
169 7 212 23 125 20 237 37 237 74 237 58 237 98 237 194 237 228 178 171 \
233 255 205 155 39 197 17 216 44 102 9 16 17 26 \
177 21 15 216 65 166 199 216 199 196 199 92 233 75 151 252 177 42 \
199 173 209 255 201 72 90 18 100 55 64 124 40 124 255 55 190 5 \
244 55 1 55 100 5 105 55 244 50 232 199 232 151 232 92 161 228 \
244 248 232 178 225 255 164 52 205 76 154 70 204 168 164 59 161 52 \
17 5 164 2 4 218 164 248 192 52 164 227 164 192 164 178 161 82 \
185 255 30 228 116 204 44 33 103 4 6 204 85 25 44 3 244 33 \
6 20 187 3 188 77 188 63 170 170 189 73 255 204 255 168 255 186 \
255 234 225 255 67 228 127 206 205 114 130 139 130 18 68 220 6 180 \
65 28 155 28 160 228 127 24 242 78 252 229 165 68 188 181 176 176"

    expected = [3, 1, 5, 0, 8, 2, 6, 7, 10, 9, 5, 
    2, 9, 5, 1, 8, 10, 3, 6, 7, 3, 10, 0, 0, 5, 
    1, 7, 2, 9, 6, 8, 8, 0, 0, 5, 9, 1, 3, 10, 
    6, 2, 7, 9, 0, 0, 8, 1, 7, 2, 5, 6, 3, 10,
    12, 0, 12, 0, 5, 3, 8, 1, 9, 7, 
    6, 10, 2, 12, 2, 3, 0, 9, 10, 5, 1, 8, 7, 
    6, 12, 0, 0, 5, 0, 2, 3, 6, 9, 10, 1, 7, 
    8, 12, 0, 2, 3, 6, 5, 1, 10, 7, 9, 8, 12, 
    0, 0, 5, 0, 8, 3, 9, 1, 6, 7, 2, 10,
    8, 5, 5, 10, 1, 1, 0, 0, 5, 0, 
    3, 9, 5, 2, 0, 0, 6, 7, 0, 0, 0, 0, 0, 
    0, 0, 0, 0, 0, 0, 0, 2, 5, 1, 3, 8, 6, 
    9, 10, 7, 0, 0, 8, 0, 0, 0, 0, 0, 1, 6, 
    0, 3, 10, 2, 5, 9, 7, 5, 10, 2, 0, 0, 1, 
    0, 2, 3, 0, 6, 0, 10, 9, 7, 8, 6, 10, 0, 
    10, 0, 6, 0, 1, 1, 0, 3, 2, 2, 5, 8, 9, 7,
    12, 5, 0, 0, 0, 0, 0, 1, 0, 0, 
    9, 8, 6, 2, 10, 3, 7, 12, 2, 0, 0, 0, 0, 
    2, 1, 2, 0, 0, 0, 3, 8, 5, 6, 9, 10, 7, 
    12, 3, 2, 2, 5, 2, 3, 0, 1, 0, 10, 3, 9, 
    8, 7, 6, 12, 0, 0, 0, 0, 0, 0, 0, 3, 0, 
    1, 6, 2, 7, 2, 9, 5, 8, 10, 12, 0, 0, 5, 
    5, 1, 0, 0, 0, 3, 9, 0, 6, 10, 2, 8, 7]

    entropy = "238 98 238 83 238 32 238 62 238 28 157 196 157 240 157 181 "
    entropy += "157 169 157 210 133 66 133 44 133 126 133 120 133 19 221 241 "
    entropy += "221 204 221 128 221 160 221 169 157 199 157 211 157 236 157 234 "
    entropy += "157 254 187 118 187 114 187 14 187 82 187 76 212 80 212 19 "
    entropy += "212 74 212 97 212 33 243 34 243 56 243 125 243 85 243 16 "
    entropy += "248 249 248 178 248 207 248 139 248 197 245 153 245 171 245 253 "
    entropy += "245 225 245 196 183 55 183 1 183 85 183 45 183 102 238 177 "
    entropy += "238 209 238 247 238 129 238 184 232 174 232 158 232 195 232 241 "
    entropy += "232 220 170 17 170 37 170 93 170 91 170 76 243 51 243 27 "
    entropy += "243 91 243 119 243 69 236 12 236 31 236 104 236 89 236 61 "
    entropy += "233 12 233 85 233 56 233 48 233 117 228 231 228 181 228 222 "
    entropy += "228 179 228 143 242 69 242 111 242 46 242 83 242 14 237 64 "
    entropy += "237 116 237 0 237 91 237 48 136 115 136 4 136 62 136 87 "
    entropy += "136 40 247 88 247 121 247 4 247 71 247 45 254 63 254 85 "
    entropy += "254 125 254 0 254 44 193 189 193 145 193 247 193 225 193 169 "
    entropy += "233 169 233 247 233 208 233 156 233 188 "

    return functional, expected, entropy


def process_input():
    fnctl, expected, entpy = get_data()
    len_exp = len(expected)
    total = failed = 0
    
    cmd = "./run.sh \"{}\" ".format(fnctl)
    output, stderr = exec_cmd(cmd)
    if output is None or stderr.find("error") >= 0 or stderr.find("dumped") >= 0 or stderr.find("fault") >= 0:
        return INF, INF
    
    output = output.split(" ")
    k = 0
    for k in range(len(output) - 1):
        if int(output[k]) != expected[k]:
            failed += 1
        k += 1
        if k == len(output):
            failed += (len_exp - k)
            break

    omap = dict()
    imap = dict()
    cmd = "./run.sh \"{}\" ".format(entpy)
    output, stderr = exec_cmd(cmd)
    if output is None or stderr.find("error") >= 0 or stderr.find("dumped") >= 0 or stderr.find("fault") >= 0:
        return INF, INF

    output = output.split(" ")
    earray = entpy.split(" ")    
    for l in range(len(earray) // 2):
        istr = str(earray[2*l])
        if istr in imap:
            imap[istr] += 1
        else: imap[istr] = 1

        ostr = output[l] + "^" + istr
        if ostr in omap:
            omap[ostr] += 1
        else:
            omap[ostr] = 1
    total += calculate_entropy(omap, imap)

    return total, failed / len_exp 


if __name__ == '__main__':
    start = time.time()
    total, failed = process_input()
    if total == INF:
        print("error:")
    else:
        max_leak = 2.3738
        print("QIF: {:.4f} Failed: {:.3f}"
              .format(total/max_leak, failed))
