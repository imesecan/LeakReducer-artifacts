#!/bin/bash
#
# Sample usage 
#    ./build.sh 
#

FNAME=classify
DRIVER=driver
CC=gcc
rm -f ${FNAME}.o *.gc* ${DRIVER}

VAR=$(${CC} -g -Werror=uninitialized -Werror=return-type -Wall -o ${FNAME}.o -c ${FNAME}.c 2>&1)

if echo "$VAR" | grep -q "error:"; then
  echo "error: $VAR"
else
	${CC} ${FNAME}.o -Wall -g -o ${DRIVER} ${DRIVER}.c
	python3 driver.py
fi

