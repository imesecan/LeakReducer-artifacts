#!/bin/bash
#
# Sample usage 
#   ./run.sh "low_1 high_1 low_2 high_2 low_3 high_3 ..."
# Sample run
#   ./run.sh "2 3 135 37 157 4"
# Sample output
#   0 3 1
#

./driver <<< $1

