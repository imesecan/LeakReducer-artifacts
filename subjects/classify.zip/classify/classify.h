/**
 * Dummy program to classify numbers 
 * to decrease information leakage
 */

#ifndef __CLASSIFY_H__
#define __CLASSIFY_H__

int classify(unsigned char low, unsigned char high);

#endif // __CLASSIFY_H__

