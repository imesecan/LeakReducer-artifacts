#include <stdio.h> 
#include "classify.h" 

int main(int argc, char *argv[])
{
	unsigned char ch;
	char h;
	
    while (scanf("%hhd", &ch) == 1) // expect 1 for successful conversion
    {
        scanf("%hhd", &h);
	    int res = classify(ch, h);
        printf("%d ", res);
    }
    printf("\n");

    return 0;
}

