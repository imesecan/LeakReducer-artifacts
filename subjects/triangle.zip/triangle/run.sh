#!/bin/bash
#
# Sample usage 
#   ./run.sh "secret_1 side2_1 side3_1 secret_2 side2_2 side3_2 ..."
# Sample run
#   ./run.sh "2 3 4 3 3 4"
# Sample output
#   1 3
#

./driver <<< $1

