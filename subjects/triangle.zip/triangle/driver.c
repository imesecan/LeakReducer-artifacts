#include <stdio.h> 
#include "triangle.h" 

int main(int argc, char *argv[])
{
	int secret, side2, side3;
	
    while (scanf("%d", &secret) == 1) // expect 1 successful conversion
    {
    	scanf("%d %d", &side2, &side3);
	    int res = triangle(secret, side2, side3);
        printf("%d ", res);
    }
    printf("\n");

    return 0;
}

