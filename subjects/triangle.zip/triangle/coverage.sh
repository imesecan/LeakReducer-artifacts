#!/bin/bash


FNAME=triangle
DRIVER=driver
EXT=c
CC=gcc

rm -f ${FNAME}.o ${DRIVER} *.gc* 

VAR=$(${CC} -g -O0 -fprofile-arcs -ftest-coverage -fprofile-generate -o ${FNAME}.o -c ${FNAME}.${EXT} 2>&1)

if echo "$VAR" | grep -q "error:"; then
  echo "error: $VAR"
else
	${CC} -g -O0 -ftest-coverage -fprofile-generate ${FNAME}.o -o ${DRIVER} ${DRIVER}.${EXT}
	python3 driver.py
	gcov -cd triangle.info
fi

