#!/bin/bash
# Sample usage for gcc
#   ./build.sh 
#

CC=gcc
FNAME="crypto/bn/bn_lib"
EXT=c
DRIVER=driver

date
rm -f ${DRIVER} ${FNAME}.o  crypto/bn/*.gc*  *.gc*
VAR=$(${CC} -Werror=uninitialized -Werror=return-type -Wall \
     -I. -Iinclude -fPIC -m64 -Wa,--noexecstack -Wall -O0 -g -g3 \
     -DOPENSSL_USE_NODELETE -DL_ENDIAN -DOPENSSL_PIC -DOPENSSL_CPUID_OBJ \
     -DOPENSSL_IA32_SSE2 -DOPENSSL_BN_ASM_MONT -DOPENSSL_BN_ASM_MONT5 \
     -DOPENSSL_BN_ASM_GF2m -DSHA1_ASM -DSHA256_ASM -DSHA512_ASM -DKECCAK1600_ASM \
     -DRC4_ASM -DMD5_ASM -DAESNI_ASM -DVPAES_ASM -DGHASH_ASM -DECP_NISTZ256_ASM \
     -DX25519_ASM -DPOLY1305_ASM -DOPENSSLDIR="\"/usr/local/ssl\"" \
     -DENGINESDIR="\"/usr/local/lib/engines-1.1\""   -MMD -MF ${FNAME}.d.tmp \
     -MT ${FNAME}.o -c -o ${FNAME}.o ${FNAME}.c 2>&1)

if echo "$VAR" | grep -q "error:"; then
  echo "error: $VAR"
else
    ar r libcrypto.a ${FNAME}.o
    ranlib libcrypto.a || echo Never mind.

    ${LDCMD:-${CC}} -I. -I./include -m64 -Wa,--noexecstack -Wall -O0 -g -g3 -L. \
    -o ${DRIVER} ${DRIVER}.c -lcrypto -ldl

    python3 driver.py
fi
date
