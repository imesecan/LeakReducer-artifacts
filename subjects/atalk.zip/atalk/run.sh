#!/bin/bash
# 
# Recieves information and runs hexadecimal input on the target file
#   and prints the output. Every call is repeated for nhigh times.
#
# Usage:
#     ./run.sh  nhigh  test_type   space_separated_hex_string
#
# Sample Usage:
#     ./run.sh 2 f "3A33DDFF3CCD7241374232453942364639090DDEECCA120000 353343736453324137AFFCD4423245394236463909000A0000"
#   *) nhigh: an integer: 2
#   *) test_type: Functional (f) or Entropy (e) 
#   Run the program repeatedly twice for the given inputs: 3A33..
#   and 3533.. for functional tests   
#
# Expected output:
#    3A33DDFF_1098042684 24
#    35334373_1093817188 24
#    3A33DDFF_1098042684 24
#    35334373_1093817188 24
#

FNAME=driver

for (( c=0; c<$1; c++)); do
    ./${FNAME} $2 $3
done
