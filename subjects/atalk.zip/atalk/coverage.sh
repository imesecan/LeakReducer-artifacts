#!/bin/bash

#echo "Compiling..."
rm -f *.gc* atalk.o 

VAR=$(g++ --coverage -g -O0 -fprofile-arcs -ftest-coverage -fprofile-generate -g -o atalk.o -c atalk.c 2>&1)

if echo "$VAR" | grep -q "error:"; then
  echo "error: $VAR"
else
	g++ -O0 -std=c++11 -ftest-coverage -fprofile-generate atalk.o -o driver driver.cpp
	python3 driver.py
	gcov -cd atalk.info
fi


