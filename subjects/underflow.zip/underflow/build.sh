#!/bin/bash
#
# build.sh is used by APR to check if the modification applied works  
#   properly and reduces the leakage of the target file (underflow.c). It   
#   first compiles the target file. If a compilation error occurs, prints 
#   “error” and quits. Otherwise, it compiles and builds driver.cpp file  
#   and runs “python3 driver.py” to generate Leakage and Fail rate  
#   information for the current underflow.c file.
#
# Sample run:
#   ./build.sh
# Sample output:
#   Leak: 1.00 Failed: 0.00; Time elapsed: 0.6 seconds
#
FNAME="underflow"
DRIVER="driver"
CC=g++
rm -f ${FNAME}.o ${DRIVER} 

VAR=$(${CC} -Werror=uninitialized -Werror=return-type -Wall -g -c -o ${FNAME}.o ${FNAME}.c 2>&1)

if echo "$VAR" | grep -q "error:"; then
  echo "error:"
else
	${CC} ${FNAME}.o  -Wall -g -o ${DRIVER} ${DRIVER}.c
	python3 driver.py
fi

