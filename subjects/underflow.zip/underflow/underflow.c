#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    nbytes = 20;
    
    if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        return 0;
    }
}



/*
ASE22/Underflow/NSGAII/641429/NSGAII-16-6414292-underflow.c 641429  0.2704  0.04    0.1552
#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    if( bufsz != h) {
      bufsz = h ;   
}
 nbytes = 20;

    if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;     // (B)

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        return 0;
    }
}



ASE22/Underflow/NSGAIII/641190/NSGAIII-19-6411901-underflow.c   641190  0   0.044   0.022


ASE22/Underflow/NSGAIII/641196/NSGAIII-24-6411960-underflow.c   641196  0.2704  0.022   0.1462
#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    nbytes = 20;

    if( bufsz < h) {
      bufsz = h ;   
    }
    if (ppos + nbytes > bufsz)     // (A)
         ;
     // (B)

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        return 0;
    }
}


ASE22/Underflow/MOCell/640844/MOCell-11-6408443-underflow.c   640844      0.2704      0.022     0.1462
#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    if( h > bufsz){
      bufsz = h; 
    }

    nbytes = 20;
    if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;     // (B)

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        return 0;
    }
}


ASE22/Underflow/MOCell/640843/MOCell-10-6408431-underflow.c   640843      0           0.044     0.022
#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    nbytes = 20;

    for(int lcv1309=0; lcv1309<1024; lcv1309++){
        bufsz = 1024;
    }
    
    if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;

    if( ppos < nbytes) {
     return 0;  
    }
      // (B)

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        return 0;
    }
}




ASE22/Underflow/NSGAII/641173/NSGAII-2-6411731-underflow.c    641173      0           0.136     0.068
#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    nbytes = 20;

    nbytes = bufsz - ppos;
    
    
    if (ppos + nbytes > bufsz)     // (A)
       nbytes = bufsz - ppos;
    
    nbytes = bufsz - ppos;
    if( ppos < nbytes) {
       return 1;  
    }
      // (B)

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        return 0;
    }
}


Original Original Original Original Original Original Original Original     1    0.0   0.5
#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    nbytes = 20;
    
    if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;     // (B)

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        return 0;
    }
}

*/