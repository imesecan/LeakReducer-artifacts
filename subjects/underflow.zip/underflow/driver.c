/*
    driver.cpp is used by build.sh and coverage.sh. it is the driver file 
    for underflow.c. It receives pairs of h and ppos values from input stream
    list. Then for each pair, it calls underflow function and prints 
    the output from the function call.
    Sample Usage
        ./executable_name 3 100 5 1200 ...
    Sample Output
        0 5
*/
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <unistd.h>
#include <cstdlib>
#include <stdint.h>
#include <stddef.h>
#include "underflow.h"

int main(int argc, char *argv[])
{
    int h; ll ppos;
    while (scanf("%d", &h) == 1) // expect 1 successful conversion
    {
    	scanf("%lld", &ppos);
	    int res = underflow(h, ppos);
        printf("%d ", res);
    }
    printf("\n");
    
    return 0;
}
