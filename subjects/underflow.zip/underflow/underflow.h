#ifndef __UNDERFLOW_H__
#define __UNDERFLOW_H__

#include <stdio.h>

typedef long long ll;
typedef unsigned int uint32;

int underflow(int h, ll ppos);

#endif /* __UNDERFLOW_H__ */
