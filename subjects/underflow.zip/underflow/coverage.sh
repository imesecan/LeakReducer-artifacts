#!/bin/bash
#
# coverage.sh is used by APR to check if the modification applied to the 
#   target file (underflow.c) works properly. If a compilation error occurs,  
#   prints “error” and quits. Otherwise, it compiles and builds driver.cpp file  
#   by using gcov and then, it runs “python3 driver.py” to generate coverage 
#   information for the target file (underflow.c.gcov). Coverage information 
#   generated is used by the APR.
#
# Sample run:
#   ./coverage.sh
# Sample output:
#   Leak: 7.20 Failed: 0.0; Time elapsed: 0.7 seconds
#   File 'underflow.c'
#   Lines executed:100.00% of 8
#   Creating 'underflow.c.gcov'
#

rm -f *.gc* driver underflow.o > /dev/null 2>&1

VAR=$(g++ --coverage -g -O0 -fprofile-arcs -ftest-coverage -fprofile-generate -c -o underflow.o underflow.c 2>&1)

if echo "$VAR" | grep -q "error:"; then
  echo "Error: $VAR"
else
	g++ -O0 -ftest-coverage -fprofile-generate underflow.o -o driver driver.c
	python3 driver.py
	gcov underflow.info
fi


