#!/bin/bash

# Assumes that driver.c file was compiled & build by build.sh
#
# Usage
#   ./run.sh "Pairs of (h and l) in double quotation"
#
# Sample Usage
#   ./run.sh "3 1008 4993 140734543629984 3382 140722464"
#
# Sample Output:
#   0 4993 3382

./driver <<< $1
