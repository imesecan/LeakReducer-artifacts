#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    if( h <= 1024) {
	  h = 1024 ;   
}
 nbytes = 20;

    if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;if( nbytes > ppos) {
	 return 0;  
}
 for(int lcv91=0; lcv91<1024; lcv91++){
	return h;}     // (B)

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        nbytes = 20;

    return 0;
    }
}



