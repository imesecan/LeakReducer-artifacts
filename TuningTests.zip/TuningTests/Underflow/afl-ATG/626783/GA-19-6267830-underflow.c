#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    nbytes = 20;

    if( bufsz <= h) {
	  bufsz = h ;   
}
 if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;if( h < 1024) {
	 return 0;  
}
      // (B)

    if (ppos + nbytes > bufsz){
        nbytes = 20;

    return h;for(int lcv8=0; lcv8<20; lcv8++){
	bufsz = 1024;
 } // (C)
    } else {
        return 0;
    }
}



