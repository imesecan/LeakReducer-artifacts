#include <stdio.h>
#include <stdlib.h>
#include "underflow.h"
#include <stdint.h>

int underflow(int h, ll ppos)
{
    int bufsz;
    uint32 nbytes;
    bufsz  = 1024;
    nbytes = 20;

    for(int lcv66=0; lcv66<1024; lcv66++){
	if (ppos + nbytes > bufsz) // (A)
 nbytes = bufsz - ppos;}if( h <= nbytes) {
	 return 1;  
}
 if (ppos + nbytes > bufsz)     // (A)
        nbytes = bufsz - ppos;     // (B)

    if (ppos + nbytes > bufsz){
        return h; // (C)
    } else {
        return 0;
    }
}



